import { ingelogd } from '../lib/auth.mjs';
import { haalOrder, bewaarOrder } from '../lib/orders.mjs';

const FASEN = ['nieuw', 'in productie', 'klaar voor levering', 'verzonden', 'gemonteerd', 'afgerond'];
const json = (data, status = 200) => Response.json(data, { status, headers: { 'cache-control': 'no-store' } });

// Beheer per bestelling: fase, interne notitie en archiveren. De bestelling zelf blijft altijd bewaard.
export default async (req) => {
  if (!ingelogd(req)) return json({ fout: 'Niet ingelogd.' }, 401);
  if (req.headers.get('x-beheer') !== '1') return json({ fout: 'Ongeldige aanvraag.' }, 400);
  let b;
  try { b = await req.json(); } catch { return json({ fout: 'Ongeldige aanvraag.' }, 400); }

  const order = await haalOrder(b.id);
  if (!order) return json({ fout: 'Bestelling niet gevonden.' }, 404);

  if (b.fase !== undefined) {
    if (!FASEN.includes(b.fase)) return json({ fout: 'Onbekende fase.' }, 400);
    order.fase = b.fase;
  }
  if (b.notitie !== undefined) order.notitie = String(b.notitie).slice(0, 1000);
  if (b.gearchiveerd !== undefined) order.gearchiveerd = b.gearchiveerd === true;
  order.bijgewerktOp = new Date().toISOString();
  await bewaarOrder(order);
  return json({ order });
};

export const config = { path: '/api/beheer/order', method: 'POST' };
