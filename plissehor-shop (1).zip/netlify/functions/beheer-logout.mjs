import { wisCookie } from '../lib/auth.mjs';

export default async () =>
  Response.json({ ok: true }, { headers: { 'set-cookie': wisCookie(), 'cache-control': 'no-store' } });

export const config = { path: '/api/beheer/logout', method: 'POST' };
