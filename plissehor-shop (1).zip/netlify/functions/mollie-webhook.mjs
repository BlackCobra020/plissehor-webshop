import { haalOrder, bewaarOrder, stuurMail, orderHtml, klantMailHtml } from '../lib/orders.mjs';
import { haalBetaling } from '../lib/mollie.mjs';

const STATUS = { paid: 'betaald', failed: 'mislukt', canceled: 'geannuleerd', expired: 'verlopen' };

export default async (req) => {
  let id = '';
  try {
    const form = await req.formData();
    id = String(form.get('id') || '');
  } catch {
    return new Response('Ongeldig verzoek', { status: 400 });
  }
  if (!/^tr_[A-Za-z0-9]+$/.test(id)) return new Response('Ongeldig id', { status: 400 });

  try {
    // De status komt altijd rechtstreeks van Mollie, nooit uit het verzoek zelf.
    const betaling = await haalBetaling(id);
    const order = await haalOrder(betaling.metadata?.orderId);
    if (!order || order.mollieId !== betaling.id) return new Response('ok');

    const nieuw = STATUS[betaling.status];
    if (!nieuw || order.status === nieuw) return new Response('ok');
    if (order.status === 'betaald') return new Response('ok'); // een betaalde bestelling blijft betaald

    order.status = nieuw;
    if (nieuw === 'betaald') order.betaaldOp = new Date().toISOString();
    await bewaarOrder(order);

    if (nieuw === 'betaald') {
      const onderwerp = order.modus === 'inmeten' ? `Inmeetaanvraag ${order.id}` : `Nieuwe bestelling ${order.id}`;
      await stuurMail(onderwerp, orderHtml(order));
      const klantOnderwerp = order.modus === 'inmeten' ? `Je inmeetaanvraag ${order.id} – Plissehor.com` : `Bevestiging van je bestelling ${order.id} – Plissehor.com`;
      await stuurMail(klantOnderwerp, klantMailHtml(order), order.klant?.email);
    }
    return new Response('ok');
  } catch (e) {
    console.error('Webhook fout', e);
    return new Response('Fout', { status: 500 }); // Mollie probeert het dan opnieuw
  }
};

export const config = { path: '/api/mollie-webhook', method: 'POST' };
