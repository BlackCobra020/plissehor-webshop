import { Fout, berekenBestelling, INMEET_KORTING_BEDRAG, eersteLeverdatum, datumNL, LEVER_WERKDAGEN } from '../../public/pricing.mjs';
import { nieuwId, haalOrder, bewaarOrder } from '../lib/orders.mjs';
import { maakBetaling } from '../lib/mollie.mjs';

const json = (data, status = 200) => Response.json(data, { status });
const tekst = (v, max) => String(v ?? '').trim().slice(0, max);

function valideerKlant(k) {
  const r = k || {};
  const klant = {
    naam: tekst(r.naam, 80),
    email: tekst(r.email, 120).toLowerCase(),
    telefoon: tekst(r.telefoon, 25),
    straat: tekst(r.straat, 100),
    postcode: tekst(r.postcode, 8).toUpperCase(),
    plaats: tekst(r.plaats, 60),
  };
  if (klant.naam.length < 2) throw new Fout('Vul je naam in.');
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(klant.email)) throw new Fout('Vul een geldig e-mailadres in.');
  if (!/^[0-9+()\-\s]{8,25}$/.test(klant.telefoon)) throw new Fout('Vul een geldig telefoonnummer in.');
  if (klant.straat.length < 4) throw new Fout('Vul je straat en huisnummer in.');
  if (!/^[1-9][0-9]{3}\s?[A-Z]{2}$/.test(klant.postcode)) throw new Fout('Vul een geldige postcode in, bijvoorbeeld 1234 AB.');
  // Alleen Nederlandse postcodes zijn toegestaan. Inmeten en montage (met voorrijkosten) zijn dus automatisch alleen in Nederland.
  if (klant.plaats.length < 2) throw new Fout('Vul je woonplaats in.');
  return klant;
}

function valideerAfspraak(a) {
  const r = a || {};
  const datum = tekst(r.datum, 10);
  const dagdeel = tekst(r.dagdeel, 10);
  if (!/^\d{4}-\d{2}-\d{2}$/.test(datum) || Number.isNaN(Date.parse(datum + 'T00:00:00Z'))) {
    throw new Fout('Kies een voorkeursdatum voor de afspraak.');
  }
  const minimaal = Date.now() + 2 * 24 * 3600 * 1000;
  if (Date.parse(datum + 'T23:59:59Z') < minimaal) throw new Fout('Kies een datum die minimaal 2 dagen vooruit ligt.');
  if (!['ochtend', 'middag'].includes(dagdeel)) throw new Fout('Kies ochtend of middag voor de afspraak.');
  return { datum, dagdeel };
}

// Controleert een inmeetcode en geeft de korting terug. Een code is eenmalig te gebruiken.
async function controleerInmeetcode(code, nieuweOrderId) {
  const o = await haalOrder(code);
  if (!o || o.modus !== 'inmeten' || o.status !== 'betaald') {
    throw new Fout('Deze inmeetcode is niet geldig. Controleer de code of laat het veld leeg.');
  }
  if (o.gebruiktDoor) {
    const vorige = await haalOrder(o.gebruiktDoor);
    if (vorige && ['open', 'betaald'].includes(vorige.status)) throw new Fout('Deze inmeetcode is al gebruikt.');
  }
  o.gebruiktDoor = nieuweOrderId;
  await bewaarOrder(o);
  return INMEET_KORTING_BEDRAG;
}

export default async (req) => {
  let body;
  try {
    body = await req.json();
  } catch {
    return json({ fout: 'Ongeldige aanvraag.' }, 400);
  }
  if (body.website) return json({ fout: 'Ongeldige aanvraag.' }, 400); // honeypot tegen spam

  try {
    if (body.akkoord !== true) throw new Fout('Ga akkoord met de algemene voorwaarden om te bestellen.');
    const modus = body.modus === 'inmeten' ? 'inmeten' : 'bestellen';
    const klant = valideerKlant(body.klant);
    const montage = modus === 'bestellen' && body.montage === true;
    const afspraak = modus === 'inmeten' || montage ? valideerAfspraak(body.afspraak) : null;
    let leverdatum = '';
    if (modus === 'bestellen' && !montage && body.leverdatum) {
      leverdatum = tekst(body.leverdatum, 10);
      const t = Date.parse(leverdatum + 'T00:00:00Z');
      if (!/^\d{4}-\d{2}-\d{2}$/.test(leverdatum) || Number.isNaN(t)) throw new Fout('Kies een geldige leverdatum.');
      const eerste = eersteLeverdatum();
      if (leverdatum < eerste) throw new Fout(`De vroegst mogelijke leverdatum is ${datumNL(eerste)} (${LEVER_WERKDAGEN} werkdagen na je bestelling). Kies deze of een latere datum, of laat het veld leeg.`);
      if (t > Date.now() + 366 * 24 * 3600 * 1000) throw new Fout('Kies een leverdatum binnen een jaar.');
    }
    const id = nieuwId();

    let kortingBedrag = 0;
    const inmeetcode = modus === 'bestellen' ? tekst(body.inmeetcode, 40).toUpperCase() : '';
    if (inmeetcode) kortingBedrag = await controleerInmeetcode(inmeetcode, id);

    const berekend = berekenBestelling({ modus, items: body.items, montage, kortingBedrag });

    const order = {
      id,
      status: 'open',
      createdAt: new Date().toISOString(),
      modus,
      klant,
      afspraak,
      leverdatum: leverdatum || null,
      montage,
      items: berekend.items,
      regels: berekend.regels,
      bedrag: berekend.totaal,
      inmeetcode: inmeetcode || null,
      opmerking: tekst(body.opmerking, 500),
    };
    await bewaarOrder(order);

    const origin = new URL(req.url).origin;
    try {
      const betaling = await maakBetaling({
        bedrag: order.bedrag,
        beschrijving: modus === 'inmeten' ? `Inmeten aan huis ${id}` : `Plissehor.com ${id}`,
        redirectUrl: `${origin}/bedankt.html?order=${id}`,
        webhookUrl: `${origin}/api/mollie-webhook`,
        orderId: id,
      });
      order.mollieId = betaling.id;
      await bewaarOrder(order);
      return json({ checkoutUrl: betaling.checkoutUrl });
    } catch (e) {
      console.error('Betaling aanmaken mislukt', e);
      order.status = 'mislukt';
      await bewaarOrder(order);
      return json({ fout: 'De betaling kon niet worden gestart. Probeer het later opnieuw.' }, 502);
    }
  } catch (e) {
    if (e instanceof Fout) return json({ fout: e.message }, 400);
    console.error(e);
    return json({ fout: 'Er ging iets mis. Probeer het later opnieuw.' }, 500);
  }
};

export const config = { path: '/api/bestel', method: 'POST' };
