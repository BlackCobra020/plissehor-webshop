import { geheim, wachtwoordKlopt, maakCookie, teVeelPogingen, registreerMislukt, wisPogingen } from '../lib/auth.mjs';

const json = (data, status = 200, headers = {}) => Response.json(data, { status, headers: { 'cache-control': 'no-store', ...headers } });

export default async (req, context) => {
  if (req.headers.get('x-beheer') !== '1') return json({ fout: 'Ongeldige aanvraag.' }, 400);
  if (!geheim()) return json({ fout: 'ADMIN_TOKEN is nog niet (of te kort, minimaal 12 tekens) ingesteld in Netlify.' }, 503);
  const ip = context?.ip;
  if (await teVeelPogingen(ip)) return json({ fout: 'Te veel pogingen. Probeer het over 15 minuten opnieuw.' }, 429);

  let body;
  try { body = await req.json(); } catch { return json({ fout: 'Ongeldige aanvraag.' }, 400); }

  if (!wachtwoordKlopt(body.wachtwoord)) {
    await registreerMislukt(ip);
    await new Promise((r) => setTimeout(r, 700)); // vertraagt het raden van wachtwoorden
    return json({ fout: 'Onjuist wachtwoord.' }, 401);
  }
  await wisPogingen(ip);
  return json({ ok: true }, 200, { 'set-cookie': maakCookie() });
};

export const config = { path: '/api/beheer/login', method: 'POST' };
