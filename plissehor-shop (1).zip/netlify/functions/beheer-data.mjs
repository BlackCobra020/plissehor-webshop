import { ingelogd } from '../lib/auth.mjs';
import { store, haalOrder } from '../lib/orders.mjs';

export default async (req) => {
  if (!ingelogd(req)) return Response.json({ fout: 'Niet ingelogd.' }, { status: 401, headers: { 'cache-control': 'no-store' } });
  const { blobs } = await store().list();
  const orders = [];
  for (let i = 0; i < blobs.length; i += 40) {
    const deel = await Promise.all(blobs.slice(i, i + 40).map((b) => haalOrder(b.key)));
    orders.push(...deel.filter(Boolean));
  }
  orders.sort((a, b) => String(b.createdAt).localeCompare(String(a.createdAt)));
  return Response.json({ orders, nu: new Date().toISOString() }, { headers: { 'cache-control': 'no-store' } });
};

export const config = { path: '/api/beheer/data', method: 'GET' };
