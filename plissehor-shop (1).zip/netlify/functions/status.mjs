import { haalOrder } from '../lib/orders.mjs';

export default async (req) => {
  const id = new URL(req.url).searchParams.get('id');
  const order = await haalOrder(id);
  if (!order) return Response.json({ fout: 'Bestelling niet gevonden.' }, { status: 404 });
  return Response.json({
    status: order.status,
    modus: order.modus,
    code: order.modus === 'inmeten' && order.status === 'betaald' ? order.id : null,
  });
};

export const config = { path: '/api/status', method: 'GET' };
