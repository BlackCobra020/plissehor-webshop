import {
  Fout, GRENZEN, LIMIETEN, DUBBELE_TYPES, PRIJZEN, eersteLeverdatum, TYPES, PROFIELEN, KLEUREN, GAAS, DESIGN_KLEUREN, INMEET_KORTING_BEDRAG,
  euro, normaliseerItem, berekenHor, berekenBestelling, beschrijfItem,
} from '/pricing.mjs';

const $ = (id) => document.getElementById(id);
const val = (name) => document.querySelector(`input[name=${name}]:checked`).value;
const m2fmt = new Intl.NumberFormat('nl-NL', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
const FRAME = { wit: '#D5DADD', antraciet: '#3A4046', bruin: '#6B4A32', lichtgrijs: '#A9AFB3', ral: '#7A8A92' };
const SLEUTEL = 'horren-wagen-v1';

// ---------- winkelwagen (bewaard in de browser) ----------
let wagen = [];
try {
  const opgeslagen = JSON.parse(localStorage.getItem(SLEUTEL) || '[]');
  wagen = (Array.isArray(opgeslagen) ? opgeslagen : []).filter((it) => {
    try { normaliseerItem(it); return true; } catch { return false; }
  });
} catch { wagen = []; }

function bewaarWagen() {
  try { localStorage.setItem(SLEUTEL, JSON.stringify(wagen)); } catch { /* geen opslag beschikbaar */ }
}

// ---------- configurator ----------
function leesConfig() {
  return {
    type: val('type'), profiel: val('profiel'), kleur: val('kleur'), ral: $('ral').value,
    gaas: val('gaas'), breedte: parseFloat($('w').value), hoogte: parseFloat($('h').value), aantal: parseInt($('q').value, 10),
  };
}

function tekenVoorbeeld(type, w, h, kleur, ok) {
  const box = { w: 320, h: 220 }, pad = 10, fc = FRAME[kleur] || 'var(--frame)';
  const s = Math.min((box.w - pad * 2) / w, (box.h - pad * 2) / h);
  const rw = ok ? w * s : 120, rh = ok ? h * s : 90;
  const x = (box.w - rw) / 2, y = (box.h - rh) / 2;
  let svg = `<svg viewBox="0 0 ${box.w} ${box.h}" width="${box.w}" height="${box.h}" role="img" aria-label="Schaalvoorbeeld van de hor">`;
  svg += '<defs><pattern id="gaas" width="6" height="6" patternUnits="userSpaceOnUse"><path d="M0 0H6M0 0V6" stroke="var(--mesh)" stroke-width="0.7" fill="none"/></pattern></defs>';
  svg += `<rect x="${x}" y="${y}" width="${rw}" height="${rh}" fill="url(#gaas)" stroke="${fc}" stroke-width="5" rx="2" opacity="${ok ? 1 : 0.35}"/>`;
  if (DUBBELE_TYPES.includes(type) && ok) {
    const mx = x + rw / 2;
    svg += `<line x1="${mx}" y1="${y}" x2="${mx}" y2="${y + rh}" stroke="${fc}" stroke-width="5"/>`;
    [0.25, 0.5, 0.75].forEach((t) => { svg += `<rect x="${mx - 4}" y="${y + rh * t - 7}" width="8" height="14" rx="2" fill="var(--accent)"/>`; });
  }
  $('preview').innerHTML = svg + '</svg>';
}

const rij = (a, b, cls) => `<tr${cls ? ` class="${cls}"` : ''}><td>${a}</td><td>${b}</td></tr>`;

function updateConfig() {
  // Een dubbele plissé hor kan alleen met het 25 mm profiel
  const dubbel = DUBBELE_TYPES.includes(val('type'));
  ['p2', 'p3', 'p4'].forEach((id) => { $(id).disabled = dubbel; });
  if (dubbel) $('p1').checked = true;
  $('profielHint').textContent = dubbel ? 'Een dubbele plissé hor is alleen met het 25 mm profiel leverbaar.' : '';
  const lim = LIMIETEN[val('type')];
  $('w').min = lim.bMin; $('w').max = lim.bMax; $('h').min = lim.hMin; $('h').max = lim.hMax;
  $('maatHint').textContent = `Breedte ${lim.bMin} tot ${lim.bMax} cm, hoogte ${lim.hMin} tot ${lim.hMax} cm.`;

  // Designprofiel: alleen wit, antraciet of RAL
  const beperkt = val('profiel') === 'design';
  ['k3', 'k4'].forEach((id) => { $(id).disabled = beperkt; });
  if (beperkt && ['bruin', 'lichtgrijs'].includes(val('kleur'))) $('k1').checked = true;
  $('kleurHint').textContent = beperkt ? 'Het designprofiel is alleen in wit, antraciet of een eigen RAL-kleur leverbaar.' : '';
  $('ralWrap').hidden = val('kleur') !== 'ral';

  const cfg = leesConfig();
  let hor = null, fout = '';
  try { hor = berekenHor(cfg); } catch (e) { fout = e instanceof Fout ? e.message : 'Controleer je invoer.'; }
  $('err').textContent = fout;
  $('toevoegen').disabled = !!fout;
  tekenVoorbeeld(cfg.type, cfg.breedte, cfg.hoogte, cfg.kleur, !fout);

  if (!hor) {
    $('cap').textContent = '';
    $('calc').innerHTML = rij('Prijs per hor', '—', 'total');
    $('note').textContent = '';
    return;
  }
  $('pollenHint').textContent = `+ ${euro(hor.oppervlakte <= 2 ? PRIJZEN.pollenKlein : PRIJZEN.pollenGroot)} per hor`;
  $('cap').textContent = `${cfg.breedte} × ${cfg.hoogte} cm${cfg.type === 'dubbel' ? ', twee schermen met magneetsluiting' : cfg.type === 'raamdubbel' ? ', twee schermen' : ''}`;

  let html = rij(`${TYPES[cfg.type]}, ${cfg.breedte} × ${cfg.hoogte} cm`, euro(hor.basis));
  if (hor.pollen) html += rij('Anti-pollengaas', `+ ${euro(hor.pollen)}`);
  html += rij('Profiel en kleur', cfg.kleur === 'ral' ? 'RAL: zie winkelwagen' : 'Inbegrepen');
  if (cfg.aantal > 1) html += rij('Per hor', euro(hor.perHor)) + rij('Aantal', `× ${cfg.aantal}`);
  html += rij('Totaal', euro(hor.regelTotaal), 'total');
  $('calc').innerHTML = html;

  const note = 'Montage, een eigen RAL-kleur en inmeten reken je in de winkelwagen af.';
  $('note').textContent = note;
}

let toastTimer;
function toon(tekst) {
  $('toast').textContent = tekst;
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => { $('toast').textContent = ''; }, 3500);
}

let bewerkIndex = null;

function stopBewerken() {
  bewerkIndex = null;
  $('toevoegen').textContent = 'Toevoegen aan winkelwagen';
  $('annuleerBewerk').hidden = true;
  $('bewerkInfo').hidden = true;
}

function startBewerken(i) {
  const it = wagen[i];
  if (!it) return;
  bewerkIndex = i;
  const zet = (naam, waarde) => { const r = document.querySelector(`input[name=${naam}][value=${waarde}]`); if (r) r.checked = true; };
  zet('type', it.type); updateConfig();      // bepaalt welke profielen kunnen
  zet('profiel', it.profiel); updateConfig(); // bepaalt welke kleuren kunnen
  zet('kleur', it.kleur);
  zet('gaas', it.gaas);
  $('ral').value = it.ral || '';
  $('w').value = String(it.breedte);
  $('h').value = String(it.hoogte);
  $('q').value = String(it.aantal);
  updateConfig();
  $('toevoegen').textContent = 'Wijzigingen opslaan';
  $('annuleerBewerk').hidden = false;
  $('bewerkInfo').textContent = `Je bewerkt hor ${i + 1} uit je winkelwagen.`;
  $('bewerkInfo').hidden = false;
  $('configurator').scrollIntoView({ behavior: 'smooth' });
}

$('toevoegen').addEventListener('click', () => {
  let item;
  try {
    item = normaliseerItem(leesConfig());
  } catch (e) {
    $('err').textContent = e instanceof Fout ? e.message : 'Controleer je invoer.';
    return;
  }
  if (bewerkIndex !== null) {
    wagen[bewerkIndex] = item;
    stopBewerken();
    bewaarWagen();
    renderWagen();
    toon('Je hor is bijgewerkt.');
    $('winkelwagen').scrollIntoView({ behavior: 'smooth' });
    return;
  }
  wagen.push(item);
  bewaarWagen();
  renderWagen();
  toon('Toegevoegd aan je winkelwagen.');
});

$('annuleerBewerk').addEventListener('click', () => { stopBewerken(); });

// ---------- winkelwagen en afrekenen ----------
function modus() { return val('modus'); }

function totaalHorren() { return wagen.reduce((som, it) => som + it.aantal, 0); }

function maakKnop(tekst, klasse, label, actie) {
  const b = document.createElement('button');
  b.type = 'button';
  b.className = klasse;
  b.textContent = tekst;
  b.setAttribute('aria-label', label);
  b.addEventListener('click', actie);
  return b;
}

function wijzigAantal(i, verschil) {
  const nieuw = wagen[i].aantal + verschil;
  $('wagenMelding').textContent = '';
  if (nieuw < 1) return;
  if (verschil > 0 && totaalHorren() + verschil > GRENZEN.maxAantal) {
    $('wagenMelding').textContent = `Je kunt maximaal ${GRENZEN.maxAantal} horren per bestelling plaatsen.`;
    return;
  }
  wagen[i].aantal = nieuw;
  bewaarWagen();
  renderWagen();
}

function verwijderRegel(i) {
  wagen.splice(i, 1);
  if (bewerkIndex !== null) {
    if (bewerkIndex === i) stopBewerken();
    else if (bewerkIndex > i) { bewerkIndex -= 1; $('bewerkInfo').textContent = `Je bewerkt hor ${bewerkIndex + 1} uit je winkelwagen.`; }
  }
  $('wagenMelding').textContent = '';
  bewaarWagen();
  renderWagen();
}

function renderWagen() {
  $('wagenAantal').textContent = String(totaalHorren());
  $('cartList').innerHTML = '';
  wagen.forEach((it, i) => {
    const li = document.createElement('li');
    const links = document.createElement('div');
    const tekst = document.createElement('div');
    tekst.textContent = beschrijfItem({ ...it, aantal: 1 }).replace(/^1× /, '');
    links.appendChild(tekst);

    const acties = document.createElement('div');
    acties.className = 'regelacties';
    const stepper = document.createElement('div');
    stepper.className = 'stepper';
    const aantal = document.createElement('span');
    aantal.textContent = String(it.aantal);
    aantal.setAttribute('aria-label', `Aantal: ${it.aantal}`);
    stepper.append(
      maakKnop('−', '', `Aantal verlagen voor hor ${i + 1}`, () => wijzigAantal(i, -1)),
      aantal,
      maakKnop('+', '', `Aantal verhogen voor hor ${i + 1}`, () => wijzigAantal(i, 1)),
    );
    acties.append(
      stepper,
      maakKnop('Bewerken', 'link', `Hor ${i + 1} bewerken`, () => startBewerken(i)),
      maakKnop('Verwijderen', 'link weg', `Hor ${i + 1} verwijderen`, () => verwijderRegel(i)),
    );
    links.appendChild(acties);

    const prijs = document.createElement('div');
    prijs.className = 'prijs';
    prijs.textContent = euro(berekenHor(it).regelTotaal);
    li.append(links, prijs);
    $('cartList').appendChild(li);
  });
  $('legeWagen').hidden = wagen.length > 0;
  updateAfrekenen();
}

function updateAfrekenen() {
  const inmeten = modus() === 'inmeten';
  $('bestelBlok').hidden = inmeten;
  $('inmetenBlok').hidden = !inmeten;
  $('afspraakBlok').hidden = !(inmeten || $('mont').checked);
  $('leverWrap').hidden = $('mont').checked;

  let html = '', ok = true;
  try {
    const kortingBedrag = !inmeten && $('inmeetcode').value.trim() ? INMEET_KORTING_BEDRAG : 0;
    const b = berekenBestelling({ modus: modus(), items: wagen, montage: $('mont').checked, kortingBedrag });
    b.regels.forEach((r) => { html += rij(r.label, r.bedrag < 0 ? `− ${euro(-r.bedrag)}` : euro(r.bedrag)); });
    html += rij('Totaal', euro(b.totaal), 'total');
  } catch {
    ok = false;
    html = rij('Totaal', '—', 'total');
  }
  $('overzicht').innerHTML = html;
  $('betaal').disabled = !ok;
}

// minimale afspraakdatum: over 3 dagen
(function zetDatum() {
  const d = new Date(Date.now() + 3 * 24 * 3600 * 1000);
  $('datum').min = d.toISOString().slice(0, 10);
  $('leverdatum').min = eersteLeverdatum();
})();

$('bestelForm').addEventListener('submit', async (e) => {
  e.preventDefault();
  $('formErr').textContent = '';
  const inmeten = modus() === 'inmeten';
  if (!inmeten && wagen.length === 0) { $('formErr').textContent = 'Je winkelwagen is leeg.'; return; }
  const afspraakNodig = inmeten || $('mont').checked;
  if (afspraakNodig && !$('datum').value) { $('formErr').textContent = 'Kies een voorkeursdatum voor de afspraak.'; return; }
  if (!$('akkoord').checked) { $('formErr').textContent = 'Ga akkoord met de algemene voorwaarden om te bestellen.'; return; }

  const payload = {
    modus: modus(),
    items: inmeten ? [] : wagen,
    montage: !inmeten && $('mont').checked,
    inmeetcode: inmeten ? '' : $('inmeetcode').value.trim(),
    leverdatum: !inmeten && !$('mont').checked ? $('leverdatum').value : '',
    afspraak: afspraakNodig ? { datum: $('datum').value, dagdeel: $('dagdeel').value } : null,
    klant: {
      naam: $('naam').value, email: $('email').value, telefoon: $('telefoon').value,
      straat: $('straat').value, postcode: $('postcode').value, plaats: $('plaats').value,
    },
    opmerking: $('opmerking').value,
    akkoord: $('akkoord').checked,
    website: $('website').value,
  };

  $('betaal').disabled = true;
  $('betaal').textContent = 'Even geduld…';
  try {
    const res = await fetch('/api/bestel', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload) });
    const data = await res.json().catch(() => ({}));
    if (res.ok && data.checkoutUrl) { window.location.href = data.checkoutUrl; return; }
    $('formErr').textContent = data.fout || 'Er ging iets mis. Probeer het later opnieuw.';
  } catch {
    $('formErr').textContent = 'Geen verbinding. Controleer je internet en probeer het opnieuw.';
  }
  $('betaal').disabled = false;
  $('betaal').textContent = 'Betalen met iDEAL';
  updateAfrekenen();
});

// ---------- koppelingen ----------
['w', 'h', 'q', 'ral'].forEach((id) => $(id).addEventListener('input', updateConfig));
document.querySelectorAll('input[name=type], input[name=profiel], input[name=kleur], input[name=gaas]').forEach((el) => el.addEventListener('change', updateConfig));
document.querySelectorAll('input[name=modus]').forEach((el) => el.addEventListener('change', updateAfrekenen));
$('mont').addEventListener('change', updateAfrekenen);
$('inmeetcode').addEventListener('input', updateAfrekenen);
$('naarInmeten').addEventListener('click', () => { $('mo2').checked = true; updateAfrekenen(); });

document.querySelectorAll('[data-kies]').forEach((a) => a.addEventListener('click', () => {
  const r = document.querySelector(`input[name=type][value=${a.dataset.kies}]`);
  if (!r) return;
  r.checked = true;
  const lim = LIMIETEN[a.dataset.kies];
  const klem = (id, min, max) => { const v = parseFloat($(id).value); if (!(v >= min)) $(id).value = String(min); else if (v > max) $(id).value = String(max); };
  klem('w', lim.bMin, lim.bMax); klem('h', lim.hMin, lim.hMax);
  updateConfig();
}));
$('serviceInmeten').addEventListener('click', () => { $('mo2').checked = true; updateAfrekenen(); });

updateConfig();
renderWagen();
