import { TYPES, PROFIELEN, KLEUREN, GAAS } from '/pricing.mjs';

const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => [...r.querySelectorAll(s)];
const eur0 = new Intl.NumberFormat('nl-NL', { style: 'currency', currency: 'EUR', maximumFractionDigits: 0 });
const eur2 = new Intl.NumberFormat('nl-NL', { style: 'currency', currency: 'EUR', minimumFractionDigits: 2 });
const getal = new Intl.NumberFormat('nl-NL', { maximumFractionDigits: 1 });
const pct = (x) => `${getal.format(x * 100)}%`;
const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const FASEN = ['nieuw', 'in productie', 'klaar voor levering', 'verzonden', 'gemonteerd', 'afgerond'];
const KORT = { enkel: 'raam/deur', schuif: 'schuifpui', dubbel: 'schuifpui dubbel', raamdubbel: 'raam dubbel' };
const MAANDEN = ['jan', 'feb', 'mrt', 'apr', 'mei', 'jun', 'jul', 'aug', 'sep', 'okt', 'nov', 'dec'];
const WEEKDAGEN = ['Ma', 'Di', 'Wo', 'Do', 'Vr', 'Za', 'Zo'];
const HEADERS = { 'content-type': 'application/json', 'x-beheer': '1' };

const state = {
  orders: [], nu: null, tab: 'overzicht',
  sort: { key: 'createdAt', dir: -1 }, pagina: 0, perPagina: 25, klantZoek: '',
};

// ---------- hulpfuncties voor gegevens ----------
const isBetaald = (o) => o.status === 'betaald';
const datum = (o) => new Date(o.betaaldOp || o.createdAt);
const aantalHorren = (o) => (o.items || []).reduce((s, i) => s + i.aantal, 0);
const som = (arr, f) => arr.reduce((s, x) => s + f(x), 0);
const m2 = (i) => (i.breedte * i.hoogte) / 10000;
const dagStart = (d) => new Date(d.getFullYear(), d.getMonth(), d.getDate());
const kleurNaam = (i) => (i.kleur === 'ral' ? `RAL ${i.ral}` : KLEUREN[i.kleur] || i.kleur);
const datumTekst = (d) => new Date(d).toLocaleDateString('nl-NL', { day: 'numeric', month: 'short', year: 'numeric' });
const datumTijd = (d) => new Date(d).toLocaleString('nl-NL', { day: 'numeric', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit' });

function splitOmzet(o) {
  const r = { horen: 0, ral: 0, montage: 0, verzending: 0, inmeten: 0, korting: 0 };
  (o.regels || []).forEach((x) => {
    const l = x.label || '';
    if (l.startsWith('Eigen RAL-kleur')) r.ral += x.bedrag;
    else if (l.startsWith('Montage')) r.montage += x.bedrag;
    else if (l.startsWith('Verzendkosten')) r.verzending += x.bedrag;
    else if (l.startsWith('Inmeetkorting')) r.korting += x.bedrag;
    else if (l.startsWith('Inmeten')) r.inmeten += x.bedrag;
    else r.horen += x.bedrag;
  });
  return r;
}

function bereik() {
  const p = $('#periode').value;
  const nu = new Date(state.nu || Date.now());
  let tot = new Date(nu.getFullYear(), nu.getMonth(), nu.getDate(), 23, 59, 59, 999);
  let van;
  if (p === 'alles') van = new Date(0);
  else if (p === 'jaar') van = new Date(nu.getFullYear(), 0, 1);
  else if (p === 'eigen') {
    van = $('#van').value ? new Date($('#van').value + 'T00:00:00') : new Date(0);
    if ($('#tot').value) tot = new Date($('#tot').value + 'T23:59:59');
  } else van = dagStart(new Date(tot.getTime() - (Number(p) - 1) * 864e5));
  const lengte = tot - van;
  const vorige = p === 'alles' || van.getTime() === 0 ? null : { van: new Date(van - lengte - 1), tot: new Date(van - 1) };
  return { van, tot, vorige };
}
const inBereik = (o, b) => { const d = datum(o); return d >= b.van && d <= b.tot; };

function kpiBereken(orders) {
  const paid = orders.filter(isBetaald);
  const best = paid.filter((o) => o.modus === 'bestellen');
  const n = best.length;
  const mislukt = orders.filter((o) => ['mislukt', 'geannuleerd', 'verlopen'].includes(o.status)).length;
  return {
    omzet: som(paid, (o) => o.bedrag), n, gem: n ? som(best, (o) => o.bedrag) / n : 0,
    horen: som(best, aantalHorren), montage: n ? best.filter((o) => o.montage).length / n : 0,
    inmeten: paid.filter((o) => o.modus === 'inmeten').length,
    mislukt: paid.length + mislukt ? mislukt / (paid.length + mislukt) : 0,
  };
}

// ---------- grafieken (SVG, zonder externe bibliotheken) ----------
function mooi(max) {
  if (max <= 0) return 1;
  const p = 10 ** Math.floor(Math.log10(max)); const m = max / p;
  return (m <= 1 ? 1 : m <= 2 ? 2 : m <= 5 ? 5 : 10) * p;
}
const W = 640, H = 250, PL = 54, PR = 10, PT = 14, PB = 38;

function rooster(max, fmt) {
  let s = '';
  [0, 0.5, 1].forEach((t) => {
    const y = PT + (H - PT - PB) * (1 - t);
    s += `<line class="rooster" x1="${PL}" x2="${W - PR}" y1="${y}" y2="${y}"/><text class="as" x="${PL - 6}" y="${y + 4}" text-anchor="end">${esc(fmt(max * t))}</text>`;
  });
  return s;
}
function labels(items, xOf) {
  const stap = Math.ceil(items.length / 12);
  return items.map((it, i) => (i % stap === 0 ? `<text class="as" x="${xOf(i)}" y="${H - 14}" text-anchor="${i === items.length - 1 && items.length > 1 ? 'end' : 'middle'}">${esc(it.l)}</text>` : '')).join('');
}
function leeg(el) { el.classList.add('chart'); el.innerHTML = '<p class="leeg">Nog geen gegevens in deze periode.</p>'; }

function staaf(el, items, fmt = getal.format) {
  if (!items.length || items.every((i) => !i.v)) return leeg(el);
  el.classList.add('chart');
  const max = mooi(Math.max(...items.map((i) => i.v)));
  const bw = (W - PL - PR) / items.length;
  const bars = items.map((it, i) => {
    const h = (it.v / max) * (H - PT - PB);
    return `<rect class="staaf" x="${PL + i * bw + bw * 0.18}" y="${PT + (H - PT - PB) - h}" width="${bw * 0.64}" height="${Math.max(h, 0)}" rx="2"><title>${esc(it.l)}: ${esc(fmt(it.v))}</title></rect>`;
  }).join('');
  el.innerHTML = `<svg viewBox="0 0 ${W} ${H}" role="img" aria-label="Staafdiagram">${rooster(max, fmt)}${bars}${labels(items, (i) => PL + i * bw + bw / 2)}</svg>`;
}

function lijn(el, items, fmt = getal.format) {
  if (!items.length || items.every((i) => !i.v)) return leeg(el);
  el.classList.add('chart');
  const max = mooi(Math.max(...items.map((i) => i.v)));
  const stap = items.length > 1 ? (W - PL - PR) / (items.length - 1) : 0;
  const x = (i) => (items.length > 1 ? PL + i * stap : PL + (W - PL - PR) / 2);
  const y = (v) => PT + (H - PT - PB) * (1 - v / max);
  const pad = items.map((it, i) => `${i ? 'L' : 'M'}${x(i)},${y(it.v)}`).join(' ');
  const vlak = `${pad} L${x(items.length - 1)},${y(0)} L${x(0)},${y(0)} Z`;
  const punten = items.map((it, i) => `<circle class="punt" cx="${x(i)}" cy="${y(it.v)}" r="3.2"><title>${esc(it.l)}: ${esc(fmt(it.v))}</title></circle>`).join('');
  el.innerHTML = `<svg viewBox="0 0 ${W} ${H}" role="img" aria-label="Lijndiagram">${rooster(max, fmt)}<path class="vlak" d="${vlak}"/><path class="lijn" d="${pad}"/>${punten}${labels(items, x)}</svg>`;
}

function hbars(el, items, fmt = (v) => getal.format(v), toonPct = true) {
  const rijen = items.filter((i) => i.v !== 0);
  if (!rijen.length) { el.innerHTML = '<p class="leeg">Nog geen gegevens in deze periode.</p>'; return; }
  const totaal = som(rijen, (i) => Math.abs(i.v)) || 1;
  const max = Math.max(...rijen.map((i) => Math.abs(i.v)));
  el.innerHTML = rijen.map((i) => `<div class="hb"><span class="l">${esc(i.l)}</span><span class="b"><i style="width:${(Math.abs(i.v) / max) * 100}%"></i></span><span class="v">${esc(fmt(i.v))}${toonPct && i.pct !== false ? ` · ${pct(Math.abs(i.v) / totaal)}` : ''}</span></div>`).join('');
}

// ---------- tabellen ----------
function kopSorteer(key, tekst, num) {
  const actief = state.sort.key === key;
  return `<th class="${num ? 'num' : ''}" aria-sort="${actief ? (state.sort.dir > 0 ? 'ascending' : 'descending') : 'none'}"><button type="button" data-sort="${key}">${tekst}${actief ? (state.sort.dir > 0 ? ' ▲' : ' ▼') : ''}</button></th>`;
}
const productTekst = (o) => {
  if (o.modus === 'inmeten') return 'Inmeten aan huis';
  const per = {};
  (o.items || []).forEach((i) => { per[i.type] = (per[i.type] || 0) + i.aantal; });
  return Object.entries(per).map(([t, n]) => `${n}× ${KORT[t] || t}`).join(', ');
};

// ---------- renderen ----------
function filterOrders() {
  const q = $('#zoek').value.trim().toLowerCase();
  const st = $('#fStatus').value, so = $('#fSoort').value, fa = $('#fFase').value, ar = $('#fArchief').value;
  const b = $('#fPeriode').checked ? bereik() : null;
  let lijst = state.orders.filter((o) => {
    if (st !== 'alle' && o.status !== st) return false;
    if (so !== 'alle' && o.modus !== so) return false;
    if (fa !== 'alle' && (o.fase || 'nieuw') !== fa) return false;
    if (ar === 'actief' && o.gearchiveerd) return false;
    if (ar === 'archief' && !o.gearchiveerd) return false;
    if (b && !inBereik(o, b)) return false;
    if (q) {
      const k = o.klant || {};
      const hooi = [o.id, k.naam, k.email, k.plaats, k.telefoon, k.postcode].join(' ').toLowerCase();
      if (!hooi.includes(q)) return false;
    }
    return true;
  });
  const { key, dir } = state.sort;
  const waarde = (o) => (key === 'bedrag' ? o.bedrag : key === 'klant' ? (o.klant?.naam || '').toLowerCase() : key === 'status' ? o.status : o.createdAt);
  lijst = lijst.sort((a, c) => (waarde(a) > waarde(c) ? 1 : waarde(a) < waarde(c) ? -1 : 0) * dir);
  return lijst;
}

function renderOrders() {
  const lijst = filterOrders();
  const paginas = Math.max(1, Math.ceil(lijst.length / state.perPagina));
  state.pagina = Math.min(state.pagina, paginas - 1);
  const deel = lijst.slice(state.pagina * state.perPagina, (state.pagina + 1) * state.perPagina);
  $('#aantalOrders').textContent = `${lijst.length} bestelling${lijst.length === 1 ? '' : 'en'} · ${eur2.format(som(lijst.filter(isBetaald), (o) => o.bedrag))} betaald`;
  $('#tabelOrders').innerHTML = `<thead><tr>${kopSorteer('createdAt', 'Datum')}<th>Bestelnr.</th>${kopSorteer('klant', 'Klant')}<th>Plaats</th><th>Producten</th>${kopSorteer('bedrag', 'Bedrag', true)}${kopSorteer('status', 'Status')}<th>Fase</th></tr></thead><tbody>${
    deel.map((o) => `<tr class="klik" tabindex="0" data-id="${esc(o.id)}"><td>${esc(datumTekst(o.createdAt))}</td><td>${esc(o.id)}</td><td>${esc(o.klant?.naam)}<br><span class="small">${esc(o.klant?.email)}</span></td><td>${esc(o.klant?.plaats)}</td><td>${esc(productTekst(o))}</td><td class="num">${eur2.format(o.bedrag)}</td><td><span class="badge ${esc(o.status)}">${esc(o.status)}</span>${o.gearchiveerd ? ' <span class="badge arch">archief</span>' : ''}</td><td>${esc(o.fase || 'nieuw')}</td></tr>`).join('') || '<tr><td colspan="8" class="leeg">Geen bestellingen gevonden.</td></tr>'
  }</tbody>`;
  $('#pager').innerHTML = paginas > 1
    ? `<button type="button" class="klein" data-pag="-1" ${state.pagina === 0 ? 'disabled' : ''}>Vorige</button><span>Pagina ${state.pagina + 1} van ${paginas}</span><button type="button" class="klein" data-pag="1" ${state.pagina >= paginas - 1 ? 'disabled' : ''}>Volgende</button>`
    : '';
}

function maandSleutel(d) { return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`; }
function maandLijst(b, orders) {
  let van = b.van.getTime() === 0 ? (orders.length ? new Date(Math.min(...orders.map((o) => datum(o)))) : b.tot) : b.van;
  const eind = b.tot;
  let m = new Date(van.getFullYear(), van.getMonth(), 1);
  const lijst = [];
  while (m <= eind && lijst.length < 60) { lijst.push({ k: maandSleutel(m), l: `${MAANDEN[m.getMonth()]} ${String(m.getFullYear()).slice(2)}` }); m = new Date(m.getFullYear(), m.getMonth() + 1, 1); }
  return lijst.slice(-24);
}
function weekStart(d) { const x = dagStart(d); const dag = (x.getDay() + 6) % 7; x.setDate(x.getDate() - dag); return x; }

function renderOverzicht() {
  const b = bereik();
  const inP = state.orders.filter((o) => inBereik(o, b));
  const k = kpiBereken(inP);
  const vorig = b.vorige ? kpiBereken(state.orders.filter((o) => inBereik(o, b.vorige))) : null;
  const delta = (cur, prev, omgekeerd) => {
    if (!vorig || !prev) return '<span class="delta">&nbsp;</span>';
    const d = (cur - prev) / prev; const goed = omgekeerd ? d < 0 : d > 0;
    return `<span class="delta ${d === 0 ? '' : goed ? 'op' : 'neer'}">${d > 0 ? '▲' : d < 0 ? '▼' : '='} ${pct(Math.abs(d))} t.o.v. vorige periode</span>`;
  };
  const kaart = (naam, waarde, d) => `<div class="kpi"><div class="naam">${naam}</div><div class="waarde">${waarde}</div>${d || '<span class="delta">&nbsp;</span>'}</div>`;
  $('#kpis').innerHTML =
    kaart('Omzet (incl. btw)', eur2.format(k.omzet), delta(k.omzet, vorig?.omzet)) +
    kaart('Bestellingen horen', k.n, delta(k.n, vorig?.n)) +
    kaart('Gem. orderwaarde', eur2.format(k.gem), delta(k.gem, vorig?.gem)) +
    kaart('Horen verkocht', k.horen, delta(k.horen, vorig?.horen)) +
    kaart('Met montage', pct(k.montage), '<span class="delta">van de bestellingen</span>') +
    kaart('Inmeetaanvragen', k.inmeten, delta(k.inmeten, vorig?.inmeten)) +
    kaart('Betaling niet gelukt', pct(k.mislukt), '<span class="delta">van alle pogingen</span>');
  $('#periodeTekst').textContent = b.van.getTime() === 0 ? 'Alle bestellingen' : `${datumTekst(b.van)} t/m ${datumTekst(b.tot)}`;

  const paid = inP.filter(isBetaald);
  const bestel = paid.filter((o) => o.modus === 'bestellen');

  // maand
  const maanden = maandLijst(b, state.orders.filter(isBetaald));
  const perM = {};
  paid.forEach((o) => { const s = maandSleutel(datum(o)); (perM[s] ||= []).push(o); });
  staaf($('#chOmzetMaand'), maanden.map((m) => ({ l: m.l, v: som(perM[m.k] || [], (o) => o.bedrag) })), (v) => eur0.format(v));
  lijn($('#chGemiddeld'), maanden.map((m) => { const bb = (perM[m.k] || []).filter((o) => o.modus === 'bestellen'); return { l: m.l, v: bb.length ? som(bb, (o) => o.bedrag) / bb.length : 0 }; }), (v) => eur0.format(v));
  // week
  const van = b.van.getTime() === 0 ? (paid.length ? new Date(Math.min(...paid.map(datum))) : b.tot) : b.van;
  let w = weekStart(van); const weken = [];
  while (w <= b.tot && weken.length < 80) { weken.push(new Date(w)); w = new Date(w.getFullYear(), w.getMonth(), w.getDate() + 7); }
  const perW = {};
  bestel.forEach((o) => { const s = weekStart(datum(o)).getTime(); perW[s] = (perW[s] || 0) + 1; });
  lijn($('#chWeek'), weken.slice(-52).map((d) => ({ l: `${d.getDate()} ${MAANDEN[d.getMonth()]}`, v: perW[d.getTime()] || 0 })), (v) => getal.format(v));

  // categorie
  const cat = { Horen: 0, 'Eigen RAL-kleur': 0, Montage: 0, Verzending: 0, Inmeten: 0, 'Inmeetkorting': 0 };
  paid.forEach((o) => { const s = splitOmzet(o); cat.Horen += s.horen; cat['Eigen RAL-kleur'] += s.ral; cat.Montage += s.montage; cat.Verzending += s.verzending; cat.Inmeten += s.inmeten; cat.Inmeetkorting += s.korting; });
  hbars($('#hbCategorie'), Object.entries(cat).map(([l, v]) => ({ l, v })), (v) => eur2.format(v));

  // inzichten
  const punten = [];
  if (vorig && vorig.omzet) { const d = (k.omzet - vorig.omzet) / vorig.omzet; punten.push(`De omzet is ${pct(Math.abs(d))} ${d >= 0 ? 'hoger' : 'lager'} dan in de vorige periode (${eur2.format(vorig.omzet)}).`); }
  const besteM = maanden.map((m) => ({ ...m, v: som(perM[m.k] || [], (o) => o.bedrag) })).sort((a, c) => c.v - a.v)[0];
  if (besteM && besteM.v > 0) punten.push(`Beste maand in deze periode: ${besteM.l} met ${eur2.format(besteM.v)}.`);
  const items = bestel.flatMap((o) => o.items || []);
  const top = (f) => { const t = {}; items.forEach((i) => { t[f(i)] = (t[f(i)] || 0) + i.aantal; }); return Object.entries(t).sort((a, c) => c[1] - a[1])[0]; };
  const tt = top((i) => TYPES[i.type] || i.type), tk = top(kleurNaam);
  if (tt) punten.push(`Meest verkocht: ${tt[0]} (${tt[1]} stuks). Populairste kleur: ${tk[0]}.`);
  if (k.n) punten.push(`${pct(k.montage)} van de bestellingen kiest voor montage en de gemiddelde bestelling is ${eur2.format(k.gem)}.`);
  if (k.mislukt > 0.2) punten.push(`Let op: ${pct(k.mislukt)} van de betaalpogingen lukt niet. Dat is hoog, controleer je betaalmethoden in Mollie.`);
  $('#inzichten').innerHTML = `<h2>Wat valt op</h2>${punten.length ? `<ul>${punten.map((p) => `<li>${esc(p)}</li>`).join('')}</ul>` : '<p class="leeg">Nog te weinig gegevens voor inzichten.</p>'}`;
}

function renderProducten() {
  const b = bereik();
  const bestel = state.orders.filter((o) => isBetaald(o) && o.modus === 'bestellen' && inBereik(o, b));
  const items = bestel.flatMap((o) => (o.items || []).map((i, n) => ({ ...i, o, n })));
  const tel = (f, namen) => { const t = {}; items.forEach((i) => { const k = f(i); t[k] = (t[k] || 0) + i.aantal; }); return Object.entries(t).sort((a, c) => c[1] - a[1]).map(([l, v]) => ({ l: namen ? (namen[l] || l) : l, v })); };
  hbars($('#hbType'), tel((i) => i.type, TYPES));
  hbars($('#hbProfiel'), tel((i) => i.profiel, PROFIELEN));
  hbars($('#hbKleur'), tel((i) => (i.kleur === 'ral' ? 'ral' : i.kleur), KLEUREN));
  hbars($('#hbGaas'), tel((i) => i.gaas, GAAS));
  const klassen = [['Kleiner dan 1 m²', 0, 1], ['1 tot 2 m²', 1, 2], ['2 tot 3 m²', 2, 3], ['3 tot 5 m²', 3, 5], ['5 tot 10 m²', 5, 10], ['10 m² en groter', 10, Infinity]];
  hbars($('#hbFormaat'), klassen.map(([l, a, c]) => ({ l, v: som(items.filter((i) => m2(i) >= a && m2(i) < c), (i) => i.aantal) })));
  const n = bestel.length || 1;
  const extra = [
    ['Met montage', bestel.filter((o) => o.montage).length], ['Eigen RAL-kleur', bestel.filter((o) => (o.items || []).some((i) => i.kleur === 'ral')).length],
    ['Met inmeetkorting', bestel.filter((o) => o.inmeetcode).length], ['Gewenste leverdatum', bestel.filter((o) => o.leverdatum).length], ['Met opmerking', bestel.filter((o) => o.opmerking).length],
  ];
  $('#hbExtras').innerHTML = bestel.length ? extra.map(([l, v]) => `<div class="hb"><span class="l">${l}</span><span class="b"><i style="width:${(v / n) * 100}%"></i></span><span class="v">${v} · ${pct(v / n)}</span></div>`).join('') : '<p class="leeg">Nog geen gegevens in deze periode.</p>';

  const maanden = maandLijst(b, state.orders.filter(isBetaald));
  const perM = {};
  items.forEach((i) => { const s = maandSleutel(datum(i.o)); perM[s] = (perM[s] || 0) + i.aantal; });
  staaf($('#chHorenMaand'), maanden.map((m) => ({ l: m.l, v: perM[m.k] || 0 })));
  const perD = [0, 0, 0, 0, 0, 0, 0];
  bestel.forEach((o) => { perD[(datum(o).getDay() + 6) % 7] += 1; });
  staaf($('#chWeekdag'), WEEKDAGEN.map((l, i) => ({ l, v: perD[i] })));

  const combi = {};
  items.forEach((i) => {
    const kl = i.kleur === 'ral' ? 'ral' : i.kleur;
    const c = (combi[`${i.type}|${i.profiel}|${kl}|${i.gaas}`] ||= { type: i.type, profiel: i.profiel, kleur: kl, gaas: i.gaas, n: 0, m2: 0, omzet: 0 });
    c.n += i.aantal; c.m2 += m2(i) * i.aantal;
    c.omzet += (i.o.regels || [])[i.n]?.bedrag || 0; // regel n hoort bij hor n
  });
  const top = Object.values(combi).sort((a, c) => c.n - a.n).slice(0, 10);
  $('#tabelCombi').innerHTML = `<thead><tr><th>Type</th><th>Profiel</th><th>Kleur</th><th>Gaas</th><th class="num">Aantal</th><th class="num">Gem. m²</th><th class="num">Omzet</th></tr></thead><tbody>${
    top.map((c) => `<tr><td>${esc(TYPES[c.type])}</td><td>${esc(PROFIELEN[c.profiel])}</td><td>${esc(KLEUREN[c.kleur])}</td><td>${esc(GAAS[c.gaas])}</td><td class="num">${c.n}</td><td class="num">${getal.format(c.m2 / c.n)}</td><td class="num">${eur2.format(c.omzet)}</td></tr>`).join('') || '<tr><td colspan="7" class="leeg">Nog geen gegevens in deze periode.</td></tr>'
  }</tbody>`;

  // van inmeten naar bestelling (alle tijd)
  const inm = state.orders.filter((o) => o.modus === 'inmeten' && isBetaald(o));
  const gebruikt = new Set(state.orders.filter((o) => o.modus === 'bestellen' && isBetaald(o) && o.inmeetcode).map((o) => o.inmeetcode));
  const omgezet = inm.filter((o) => gebruikt.has(o.id)).length;
  $('#inmetenFunnel').innerHTML = inm.length
    ? `<p class="small">Over alle bestellingen heen.</p>` + [['Betaalde inmeetaanvragen', inm.length], ['Daarna een bestelling geplaatst', omgezet], ['Nog niet besteld', inm.length - omgezet]]
        .map(([l, v]) => `<div class="hb"><span class="l">${l}</span><span class="b"><i style="width:${(v / inm.length) * 100}%"></i></span><span class="v">${v} · ${pct(v / inm.length)}</span></div>`).join('')
    : '<p class="leeg">Er zijn nog geen inmeetaanvragen.</p>';
}

function klantenLijst() {
  const m = new Map();
  state.orders.filter(isBetaald).forEach((o) => {
    const k = o.klant || {}; const sleutel = String(k.email || o.id).toLowerCase();
    const c = m.get(sleutel) || { naam: k.naam, email: k.email, telefoon: k.telefoon, plaats: k.plaats, n: 0, horen: 0, omzet: 0, eerste: o.createdAt, laatste: o.createdAt };
    c.n += 1; c.horen += aantalHorren(o); c.omzet += o.bedrag;
    if (o.createdAt < c.eerste) c.eerste = o.createdAt;
    if (o.createdAt >= c.laatste) { c.laatste = o.createdAt; c.naam = k.naam; c.plaats = k.plaats; c.telefoon = k.telefoon; }
    m.set(sleutel, c);
  });
  return [...m.values()];
}

function renderKlanten() {
  const alle = klantenLijst();
  const herhaal = alle.filter((c) => c.n >= 2).length;
  const b = bereik();
  const nieuw = alle.filter((c) => { const d = new Date(c.eerste); return d >= b.van && d <= b.tot; }).length;
  const kaart = (naam, w, d) => `<div class="kpi"><div class="naam">${naam}</div><div class="waarde">${w}</div><span class="delta">${d || '&nbsp;'}</span></div>`;
  $('#klantKpis').innerHTML = kaart('Klanten totaal', alle.length) + kaart('Herhaalklanten', pct(alle.length ? herhaal / alle.length : 0), `${herhaal} klanten met 2 of meer bestellingen`) +
    kaart('Gem. besteding per klant', eur2.format(alle.length ? som(alle, (c) => c.omzet) / alle.length : 0)) + kaart('Nieuwe klanten', nieuw, 'in de gekozen periode');
  const q = state.klantZoek.toLowerCase();
  const lijst = alle.filter((c) => !q || [c.naam, c.email, c.plaats].join(' ').toLowerCase().includes(q)).sort((a, c) => c.omzet - a.omzet);
  $('#tabelKlanten').innerHTML = `<thead><tr><th>Naam</th><th>E-mail</th><th>Plaats</th><th class="num">Bestellingen</th><th class="num">Horen</th><th class="num">Omzet</th><th>Laatste bestelling</th></tr></thead><tbody>${
    lijst.slice(0, 200).map((c) => `<tr><td>${esc(c.naam)}</td><td>${esc(c.email)}</td><td>${esc(c.plaats)}</td><td class="num">${c.n}</td><td class="num">${c.horen}</td><td class="num">${eur2.format(c.omzet)}</td><td>${esc(datumTekst(c.laatste))}</td></tr>`).join('') || '<tr><td colspan="7" class="leeg">Geen klanten gevonden.</td></tr>'
  }</tbody>`;
  const per = {};
  state.orders.filter((o) => isBetaald(o) && o.modus === 'bestellen').forEach((o) => { const p = (o.klant?.plaats || 'Onbekend').trim(); per[p] = (per[p] || 0) + 1; });
  hbars($('#hbPlaats'), Object.entries(per).sort((a, c) => c[1] - a[1]).slice(0, 8).map(([l, v]) => ({ l, v })));
}

function renderArchief() {
  const totaal = state.orders.length, arch = state.orders.filter((o) => o.gearchiveerd).length;
  const eerste = state.orders.length ? datumTekst(state.orders.reduce((m, o) => (o.createdAt < m ? o.createdAt : m), state.orders[0].createdAt)) : '–';
  $('#archiefStand').textContent = `${totaal} bestellingen opgeslagen sinds ${eerste}, waarvan ${arch} gearchiveerd.`;
}

function renderAlles() {
  const tab = state.tab;
  $('#periodebalk').hidden = !['overzicht', 'producten', 'klanten', 'archief'].includes(tab);
  if (tab === 'overzicht') renderOverzicht();
  else if (tab === 'bestellingen') renderOrders();
  else if (tab === 'producten') renderProducten();
  else if (tab === 'klanten') renderKlanten();
  else if (tab === 'archief') renderArchief();
}

// ---------- detailvenster ----------
function openDetail(id) {
  const o = state.orders.find((x) => x.id === id); if (!o) return;
  const k = o.klant || {};
  const regels = (o.regels || []).map((r) => `<tr><td>${esc(r.label)}</td><td>${r.bedrag < 0 ? '− ' + eur2.format(-r.bedrag) : eur2.format(r.bedrag)}</td></tr>`).join('');
  const prod = (o.items || []).map((i) => `<tr><td>${i.aantal}×</td><td>${esc(TYPES[i.type])}<br><span class="small">${i.breedte} × ${i.hoogte} cm · ${getal.format(m2(i))} m² · ${esc(PROFIELEN[i.profiel])} · ${esc(kleurNaam(i))} · ${esc(GAAS[i.gaas])}</span></td></tr>`).join('');
  $('#modalInhoud').innerHTML = `<h2 id="modalTitel">${esc(o.id)}</h2>
    <p><span class="badge ${esc(o.status)}">${esc(o.status)}</span> ${o.gearchiveerd ? '<span class="badge arch">archief</span>' : ''} <span class="small">besteld ${esc(datumTijd(o.createdAt))}${o.betaaldOp ? ' · betaald ' + esc(datumTijd(o.betaaldOp)) : ''}</span></p>
    <div class="detailgrid">
      <div><h3>Klant</h3>${esc(k.naam)}<br>${esc(k.straat)}<br>${esc(k.postcode)} ${esc(k.plaats)}<br><a href="mailto:${esc(k.email)}">${esc(k.email)}</a><br><a href="tel:${esc(k.telefoon)}">${esc(k.telefoon)}</a></div>
      <div><h3>Levering en afspraak</h3>${o.modus === 'inmeten' ? 'Inmeetaanvraag' : o.montage ? 'Met montage' : 'Alleen levering'}<br>${o.afspraak ? `Voorkeur: ${esc(o.afspraak.datum)} (${esc(o.afspraak.dagdeel)})<br>` : ''}${o.leverdatum ? `Levering vanaf: ${esc(o.leverdatum)}<br>` : ''}${o.inmeetcode ? `Inmeetcode: ${esc(o.inmeetcode)}<br>` : ''}${o.mollieId ? `<span class="small">Mollie: ${esc(o.mollieId)}</span>` : ''}</div>
    </div>
    ${prod ? `<h3>Producten</h3><table class="data"><tbody>${prod}</tbody></table>` : ''}
    <h3>Bedragen</h3><table class="data"><tbody>${regels}<tr><td><b>Totaal</b></td><td><b>${eur2.format(o.bedrag)}</b></td></tr></tbody></table>
    ${o.opmerking ? `<h3>Opmerking van de klant</h3><p>${esc(o.opmerking)}</p>` : ''}
    <h3>Beheer</h3>
    <div class="beheerrij"><label for="mFase">Fase</label><select id="mFase">${FASEN.map((f) => `<option ${((o.fase || 'nieuw') === f) ? 'selected' : ''}>${f}</option>`).join('')}</select>
    <label class="inline"><input type="checkbox" id="mArch" ${o.gearchiveerd ? 'checked' : ''}> Archiveren (verbergen uit de actieve lijst)</label></div>
    <label for="mNotitie">Interne notitie (niet zichtbaar voor de klant)</label><textarea id="mNotitie" maxlength="1000">${esc(o.notitie || '')}</textarea>
    <div class="beheerrij"><button type="button" class="klein goud" id="mOpslaan" data-id="${esc(o.id)}">Opslaan</button><span class="small" id="mMelding"></span></div>`;
  $('#modal').hidden = false; $('#modal').scrollTop = 0; document.body.style.overflow = 'hidden';
  $('#modalSluit').focus();
}
function sluitDetail() { $('#modal').hidden = true; $('#modalInhoud').innerHTML = ''; document.body.style.overflow = ''; }

let toastT;
function toast(t) { $('#toast').textContent = t; clearTimeout(toastT); toastT = setTimeout(() => { $('#toast').textContent = ''; }, 3000); }

async function slaOp(id) {
  const body = { id, fase: $('#mFase').value, notitie: $('#mNotitie').value, gearchiveerd: $('#mArch').checked };
  $('#mMelding').textContent = 'Opslaan…';
  try {
    const res = await fetch('/api/beheer/order', { method: 'POST', headers: HEADERS, body: JSON.stringify(body) });
    const data = await res.json();
    if (!res.ok) throw new Error(data.fout || 'Opslaan mislukt.');
    const i = state.orders.findIndex((x) => x.id === id);
    if (i >= 0) state.orders[i] = data.order;
    sluitDetail(); renderAlles(); toast('Opgeslagen.');
  } catch (e) { $('#mMelding').textContent = e.message; }
}

// ---------- export ----------
function csvCel(v) {
  if (v && typeof v === 'object') return Number.isFinite(v.bedrag) ? v.bedrag.toFixed(2).replace('.', ',') : '';
  if (typeof v === 'number') return String(Math.round(v * 100) / 100).replace('.', ',');
  let s = v == null ? '' : String(v);
  if (/^[=+\-@\t\r]/.test(s)) s = "'" + s; // voorkomt dat Excel tekst als formule uitvoert
  return /[";\n\r]/.test(s) ? '"' + s.replace(/"/g, '""') + '"' : s;
}
function maakCsv(kop, rijen) { return '\ufeff' + [kop, ...rijen].map((r) => r.map(csvCel).join(';')).join('\r\n'); }
function download(naam, inhoud, mime) {
  const a = document.createElement('a');
  a.href = URL.createObjectURL(new Blob([inhoud], { type: mime }));
  a.download = naam; document.body.appendChild(a); a.click(); a.remove();
  setTimeout(() => URL.revokeObjectURL(a.href), 3000);
}
function exportDoe(soort) {
  const b = bereik();
  const orders = state.orders.filter((o) => $('#exportBereik').value === 'alles' || inBereik(o, b));
  const stempel = new Date(state.nu || Date.now()).toISOString().slice(0, 10);
  if (soort === 'json') return download(`plissehor-backup-${stempel}.json`, JSON.stringify(orders, null, 2), 'application/json');
  if (soort === 'bestellingen') {
    const kop = ['Bestelnummer', 'Besteld op', 'Betaald op', 'Status', 'Soort', 'Fase', 'Gearchiveerd', 'Naam', 'E-mail', 'Telefoon', 'Adres', 'Postcode', 'Plaats', 'Aantal horen', 'Montage', 'Afspraak datum', 'Dagdeel', 'Gewenste leverdatum', 'Inmeetcode', 'Totaal incl. btw', 'Omzet horen', 'Eigen RAL', 'Montage bedrag', 'Verzending', 'Inmeten', 'Inmeetkorting', 'Opmerking klant', 'Interne notitie'];
    const bd = (n) => ({ bedrag: n });
    const rijen = orders.map((o) => { const s = splitOmzet(o), k = o.klant || {}; return [o.id, o.createdAt, o.betaaldOp || '', o.status, o.modus, o.fase || 'nieuw', o.gearchiveerd ? 'ja' : 'nee', k.naam, k.email, k.telefoon, k.straat, k.postcode, k.plaats, aantalHorren(o), o.montage ? 'ja' : 'nee', o.afspraak?.datum || '', o.afspraak?.dagdeel || '', o.leverdatum || '', o.inmeetcode || '', bd(o.bedrag), bd(s.horen), bd(s.ral), bd(s.montage), bd(s.verzending), bd(s.inmeten), bd(s.korting), o.opmerking || '', o.notitie || '']; });
    return download(`plissehor-bestellingen-${stempel}.csv`, maakCsv(kop, rijen), 'text/csv;charset=utf-8');
  }
  if (soort === 'regels') {
    const kop = ['Bestelnummer', 'Datum', 'Status', 'Klant', 'E-mail', 'Plaats', 'Type', 'Profiel', 'Kleur', 'Gaas', 'Breedte (cm)', 'Hoogte (cm)', 'm² per hor', 'Aantal', 'Regelbedrag incl. btw'];
    const rijen = orders.flatMap((o) => (o.items || []).map((i, n) => [o.id, o.betaaldOp || o.createdAt, o.status, o.klant?.naam, o.klant?.email, o.klant?.plaats, TYPES[i.type], PROFIELEN[i.profiel], kleurNaam(i), GAAS[i.gaas], i.breedte, i.hoogte, m2(i), i.aantal, { bedrag: (o.regels || [])[n]?.bedrag }]));
    return download(`plissehor-producten-${stempel}.csv`, maakCsv(kop, rijen), 'text/csv;charset=utf-8');
  }
  if (soort === 'klanten') {
    const kop = ['Naam', 'E-mail', 'Telefoon', 'Plaats', 'Bestellingen', 'Aantal horen', 'Omzet incl. btw', 'Eerste bestelling', 'Laatste bestelling'];
    const rijen = klantenLijst().sort((a, c) => c.omzet - a.omzet).map((c) => [c.naam, c.email, c.telefoon, c.plaats, c.n, c.horen, { bedrag: c.omzet }, c.eerste, c.laatste]);
    return download(`plissehor-klanten-${stempel}.csv`, maakCsv(kop, rijen), 'text/csv;charset=utf-8');
  }
}

// ---------- inloggen en laden ----------
function toonLogin() { $('#login').hidden = false; $('#app').hidden = true; $('#ww').focus(); }
async function laad() {
  let res;
  try { res = await fetch('/api/beheer/data', { credentials: 'same-origin' }); } catch { toonLogin(); $('#loginFout').textContent = 'Geen verbinding.'; return; }
  if (res.status === 401) return toonLogin();
  if (!res.ok) { toonLogin(); $('#loginFout').textContent = 'De gegevens konden niet worden geladen.'; return; }
  const data = await res.json();
  state.orders = data.orders || []; state.nu = data.nu;
  $('#login').hidden = true; $('#app').hidden = false;
  $('#bijgewerkt').textContent = `Bijgewerkt ${new Date(data.nu).toLocaleTimeString('nl-NL', { hour: '2-digit', minute: '2-digit' })}`;
  $('#fFase').innerHTML = '<option value="alle">Alle fasen</option>' + FASEN.map((f) => `<option>${f}</option>`).join('');
  wissel(location.hash.replace('#', '') || state.tab, false);
}

function wissel(tab, zetHash = true) {
  if (!['overzicht', 'bestellingen', 'producten', 'klanten', 'archief'].includes(tab)) tab = 'overzicht';
  state.tab = tab;
  $$('.tabs button').forEach((b) => b.setAttribute('aria-selected', String(b.dataset.tab === tab)));
  $$('.tabvlak').forEach((s) => { s.hidden = s.id !== `tab-${tab}`; });
  if (zetHash) history.replaceState(null, '', `#${tab}`);
  renderAlles();
}

$('#loginForm').addEventListener('submit', async (e) => {
  e.preventDefault(); $('#loginFout').textContent = '';
  const res = await fetch('/api/beheer/login', { method: 'POST', headers: HEADERS, body: JSON.stringify({ wachtwoord: $('#ww').value }) });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) { $('#loginFout').textContent = data.fout || 'Inloggen mislukt.'; return; }
  $('#ww').value = ''; laad();
});
$('#uitloggen').addEventListener('click', async () => { await fetch('/api/beheer/logout', { method: 'POST', headers: HEADERS }); state.orders = []; toonLogin(); });
$('#vernieuw').addEventListener('click', async () => { await laad(); toast('Gegevens vernieuwd.'); });
$$('.tabs button').forEach((b) => b.addEventListener('click', () => wissel(b.dataset.tab)));
$('#periode').addEventListener('change', () => { $('#eigenPeriode').hidden = $('#periode').value !== 'eigen'; renderAlles(); });
['van', 'tot'].forEach((id) => $('#' + id).addEventListener('change', renderAlles));
['zoek', 'fStatus', 'fSoort', 'fFase', 'fArchief', 'fPeriode'].forEach((id) => $('#' + id).addEventListener('input', () => { state.pagina = 0; renderOrders(); }));
$('#zoekKlant').addEventListener('input', (e) => { state.klantZoek = e.target.value; renderKlanten(); });
$('#tabelOrders').addEventListener('click', (e) => {
  const s = e.target.closest('[data-sort]');
  if (s) { const key = s.dataset.sort; state.sort = { key, dir: state.sort.key === key ? -state.sort.dir : -1 }; renderOrders(); return; }
  const r = e.target.closest('tr[data-id]'); if (r) openDetail(r.dataset.id);
});
$('#tabelOrders').addEventListener('keydown', (e) => { if (e.key === 'Enter') { const r = e.target.closest('tr[data-id]'); if (r) openDetail(r.dataset.id); } });
$('#pager').addEventListener('click', (e) => { const p = e.target.closest('[data-pag]'); if (p) { state.pagina += Number(p.dataset.pag); renderOrders(); } });
$('#modalSluit').addEventListener('click', sluitDetail);
$('#modal').addEventListener('click', (e) => { if (e.target === $('#modal')) sluitDetail(); const o = e.target.closest('#mOpslaan'); if (o) slaOp(o.dataset.id); });
document.addEventListener('keydown', (e) => { if (e.key === 'Escape' && !$('#modal').hidden) sluitDetail(); });
$$('[data-export]').forEach((b) => b.addEventListener('click', () => exportDoe(b.dataset.export)));

laad();
