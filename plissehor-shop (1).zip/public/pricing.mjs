// Gedeelde prijsberekening: wordt door de winkel (browser) en door de server gebruikt.
// De server rekent de prijs altijd zelf opnieuw uit, zodat de prijs niet te manipuleren is.

export class Fout extends Error {}

export const GRENZEN = { min: 20, max: 400, dubbelMinBreedte: 170, maxAantal: 50 };

export const PRIJZEN = {
  basis: { enkel: 95, schuif: 95, dubbel: 105, raamdubbel: 105 }, // per m2 en minimumprijs
  staffel2: 88 / 95, // 2 tot 3 m2
  staffel3: 81 / 95, // vanaf 3 m2
  pollenKlein: 10, // tot en met 2 m2
  pollenGroot: 20, // boven 2 m2
  ralPrijs: 150, // per blok van 8 horren
  ralBlok: 8,
  verzenden: 10, // vaste verzendkosten per bestelling (gratis bij montage, dan brengen wij de hor zelf mee)
  voorrij: 100, // montage: vaste voorrijkosten
  montageEerste: 50, // eerste hor
  montageExtra: 20, // elke extra hor
  inmeten: 80, // inmeten aan huis: vaste voorrijkosten
  inmeetKorting: 0.5, // 50% wordt verrekend bij een bestelling
};

export const TYPES = {
  enkel: 'Plissé raam- of deurhor',
  schuif: 'Plissé schuifpuihor, enkel',
  dubbel: 'Plissé schuifpuihor, dubbel',
  raamdubbel: 'Plissé raamhor, dubbel',
};
export const PROFIELEN = {
  p25: '25 mm profiel',
  p18: '18 mm profiel',
  p18r: '18 mm profiel met rand',
  design: 'Designprofiel',
};
export const KLEUREN = {
  wit: 'Wit',
  antraciet: 'Antraciet',
  bruin: 'Bruin',
  lichtgrijs: 'Lichtgrijs',
  ral: 'Eigen RAL-kleur',
};
export const GAAS = { standaard: 'Standaard gaas', pollen: 'Anti-pollengaas' };
export const DESIGN_KLEUREN = ['wit', 'antraciet', 'ral'];
// Een dubbele plissé hor kan alleen met het standaard aluminium frame (25 mm).
export const DUBBEL_PROFIELEN = ['p25'];
export const DUBBELE_TYPES = ['dubbel', 'raamdubbel'];

// Minimale en maximale maten (cm) per type.
export const LIMIETEN = {
  enkel: { bMin: 20, bMax: 400, hMin: 20, hMax: 400 },
  schuif: { bMin: 20, bMax: 400, hMin: 150, hMax: 400 },
  dubbel: { bMin: 170, bMax: 400, hMin: 150, hMax: 400 },
  raamdubbel: { bMin: 100, bMax: 400, hMin: 20, hMax: 150 },
};

const r2 = (x) => Math.round(x * 100) / 100;

export const euro = (n) =>
  new Intl.NumberFormat('nl-NL', { style: 'currency', currency: 'EUR', minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(n);

export function normaliseerItem(raw) {
  const r = raw || {};
  const type = String(r.type);
  if (!TYPES[type]) throw new Fout('Onbekend type hor.');
  const profiel = String(r.profiel);
  if (!PROFIELEN[profiel]) throw new Fout('Onbekend profiel.');
  if (DUBBELE_TYPES.includes(type) && !DUBBEL_PROFIELEN.includes(profiel)) {
    throw new Fout('Een dubbele plissé hor is alleen met het 25 mm profiel leverbaar.');
  }
  const kleur = String(r.kleur);
  if (!KLEUREN[kleur]) throw new Fout('Onbekende kleur.');
  if (profiel === 'design' && !DESIGN_KLEUREN.includes(kleur)) {
    throw new Fout('Het designprofiel is alleen in wit, antraciet of een eigen RAL-kleur leverbaar.');
  }
  let ral = '';
  if (kleur === 'ral') {
    ral = String(r.ral || '').replace(/^\s*ral\s*/i, '').trim();
    if (!/^\d{4}$/.test(ral)) throw new Fout('Vul een RAL-nummer van 4 cijfers in, bijvoorbeeld 7016.');
  }
  const gaas = String(r.gaas);
  if (!GAAS[gaas]) throw new Fout('Onbekend type gaas.');

  const breedte = Number(r.breedte);
  const hoogte = Number(r.hoogte);
  const aantal = Number(r.aantal);
  if (!Number.isFinite(breedte) || !Number.isFinite(hoogte) || breedte <= 0 || hoogte <= 0) {
    throw new Fout('Vul breedte en hoogte in.');
  }
  if (!Number.isInteger(breedte) || !Number.isInteger(hoogte)) throw new Fout('Gebruik hele centimeters.');
  const lim = LIMIETEN[type];
  const naam = TYPES[type].toLowerCase();
  if (breedte < lim.bMin) throw new Fout(`De breedte van een ${naam} is minimaal ${lim.bMin} cm.`);
  if (breedte > lim.bMax) throw new Fout(`De breedte van een ${naam} is maximaal ${lim.bMax} cm.`);
  if (hoogte < lim.hMin) throw new Fout(`De hoogte van een ${naam} is minimaal ${lim.hMin} cm.`);
  if (hoogte > lim.hMax) throw new Fout(`De hoogte van een ${naam} is maximaal ${lim.hMax} cm.`);
  if (!Number.isInteger(aantal) || aantal < 1 || aantal > GRENZEN.maxAantal) {
    throw new Fout(`Kies een aantal tussen 1 en ${GRENZEN.maxAantal}.`);
  }
  return { type, profiel, kleur, ral, gaas, breedte, hoogte, aantal };
}

// Prijs van één scherm zonder toeslagen. cm2 = breedte x hoogte in cm².
function basisPrijs(cm2, base) {
  const A = cm2 / 10000;
  if (cm2 <= 10000) return { prijs: base, label: 'Tot 1 m²: vast tarief', vastTot: null };
  if (cm2 <= 20000) return { prijs: A * base, label: `1 tot 2 m²: ${euro(base)} per m²`, vastTot: null };
  if (cm2 <= 30000) {
    const tarief = base * PRIJZEN.staffel2;
    const raw = A * tarief;
    const vloer = 2 * base; // een groter scherm is nooit goedkoper dan een kleiner scherm
    return { prijs: Math.max(raw, vloer), label: `2 tot 3 m²: ${euro(r2(tarief))} per m²`, vastTot: raw < vloer ? vloer / tarief : null };
  }
  const tarief = base * PRIJZEN.staffel3;
  const raw = A * tarief;
  const vloer = 3 * base * PRIJZEN.staffel2;
  return { prijs: Math.max(raw, vloer), label: `Vanaf 3 m²: ${euro(r2(tarief))} per m²`, vastTot: raw < vloer ? vloer / tarief : null };
}

export function berekenHor(raw) {
  const it = normaliseerItem(raw);
  const cm2 = it.breedte * it.hoogte;
  const A = cm2 / 10000;
  const b = basisPrijs(cm2, PRIJZEN.basis[it.type]);
  const basis = Math.ceil(r2(b.prijs)); // altijd naar boven afronden op hele euro's
  const pollen = it.gaas === 'pollen' ? (cm2 <= 20000 ? PRIJZEN.pollenKlein : PRIJZEN.pollenGroot) : 0;
  const perHor = basis + pollen;
  return { item: it, oppervlakte: A, basis, pollen, perHor, regelTotaal: perHor * it.aantal, staffelLabel: b.label, vastTot: b.vastTot };
}

export function beschrijfItem(raw) {
  const it = normaliseerItem(raw);
  const kleur = it.kleur === 'ral' ? `RAL ${it.ral}` : KLEUREN[it.kleur].toLowerCase();
  return `${it.aantal}× ${TYPES[it.type]}, ${it.breedte} × ${it.hoogte} cm, ${PROFIELEN[it.profiel]}, ${kleur}, ${GAAS[it.gaas].toLowerCase()}`;
}

export function berekenBestelling({ modus, items = [], montage = false, kortingBedrag = 0 }) {
  if (modus === 'inmeten') {
    return {
      regels: [{ label: 'Inmeten aan huis: voorrijkosten', bedrag: PRIJZEN.inmeten }],
      totaal: PRIJZEN.inmeten,
      aantalHorren: 0,
      items: [],
    };
  }
  if (modus !== 'bestellen') throw new Fout('Onbekende bestelmodus.');
  if (!Array.isArray(items) || items.length === 0) throw new Fout('Je winkelwagen is leeg.');
  if (items.length > 30) throw new Fout('Je winkelwagen bevat te veel regels.');

  const schoon = items.map(normaliseerItem);
  const n = schoon.reduce((s, it) => s + it.aantal, 0);
  if (n > GRENZEN.maxAantal) throw new Fout(`Je kunt maximaal ${GRENZEN.maxAantal} horren per bestelling plaatsen.`);

  const regels = schoon.map((it) => ({ label: beschrijfItem(it), bedrag: berekenHor(it).regelTotaal }));

  const nRal = schoon.filter((it) => it.kleur === 'ral').reduce((s, it) => s + it.aantal, 0);
  if (nRal > 0) {
    regels.push({
      label: `Eigen RAL-kleur (${nRal} ${nRal === 1 ? 'hor' : 'horren'})`,
      bedrag: Math.ceil(nRal / PRIJZEN.ralBlok) * PRIJZEN.ralPrijs,
    });
  }
  if (montage) {
    regels.push({ label: 'Montage: voorrijkosten', bedrag: PRIJZEN.voorrij });
    regels.push({
      label: n === 1 ? 'Montage (1 hor)' : `Montage (${n} horren: 1e hor ${euro(PRIJZEN.montageEerste)}, extra horren ${euro(PRIJZEN.montageExtra)} per stuk)`,
      bedrag: PRIJZEN.montageEerste + PRIJZEN.montageExtra * (n - 1),
    });
  }
  regels.push(
    montage
      ? { label: 'Verzendkosten (bij montage brengen wij je hor zelf mee)', bedrag: 0 }
      : { label: 'Verzendkosten', bedrag: PRIJZEN.verzenden },
  );
  if (kortingBedrag > 0) regels.push({ label: 'Inmeetkorting (50% van de inmeetkosten)', bedrag: -kortingBedrag });

  const totaal = regels.reduce((s, r) => s + r.bedrag, 0);
  return { regels, totaal, aantalHorren: n, items: schoon };
}

export const INMEET_KORTING_BEDRAG = PRIJZEN.inmeten * PRIJZEN.inmeetKorting;

// ---------- Werkdagen en leverdatum ----------
export const LEVER_WERKDAGEN = 10; // vroegst mogelijke gewenste leverdatum: 10 werkdagen na de bestelling

const iso = (d) => d.toISOString().slice(0, 10);
const utc = (j, m, d) => new Date(Date.UTC(j, m, d));
const plusDagen = (d, n) => utc(d.getUTCFullYear(), d.getUTCMonth(), d.getUTCDate() + n);

function paaszondag(j) {
  const a = j % 19, b = Math.floor(j / 100), c = j % 100, d = Math.floor(b / 4), e = b % 4, f = Math.floor((b + 8) / 25);
  const g = Math.floor((b - f + 1) / 3), h = (19 * a + b - d - g + 15) % 30, i = Math.floor(c / 4), k = c % 4;
  const l = (32 + 2 * e + 2 * i - h - k) % 7, m = Math.floor((a + 11 * h + 22 * l) / 451);
  const maand = Math.floor((h + l - 7 * m + 114) / 31), dag = ((h + l - 7 * m + 114) % 31) + 1;
  return utc(j, maand - 1, dag);
}

// Nationale feestdagen waarop wij niet werken (Nieuwjaar, Pasen, Koningsdag, Hemelvaart, Pinksteren, Kerst).
export function feestdagen(jaar) {
  const pasen = paaszondag(jaar);
  const koningsdag = utc(jaar, 3, 27).getUTCDay() === 0 ? utc(jaar, 3, 26) : utc(jaar, 3, 27);
  return new Set([utc(jaar, 0, 1), pasen, plusDagen(pasen, 1), koningsdag, plusDagen(pasen, 39), plusDagen(pasen, 49), plusDagen(pasen, 50), utc(jaar, 11, 25), utc(jaar, 11, 26)].map(iso));
}

const isWerkdag = (d) => d.getUTCDay() !== 0 && d.getUTCDay() !== 6 && !feestdagen(d.getUTCFullYear()).has(iso(d));

// Datum van vandaag in Nederland (YYYY-MM-DD), voor browser en server hetzelfde.
export const vandaagNL = () => new Intl.DateTimeFormat('en-CA', { timeZone: 'Europe/Amsterdam' }).format(new Date());

// De vroegste leverdatum: het aantal werkdagen na de bestelling (de besteldag zelf telt niet mee).
export function eersteLeverdatum(vanaf = vandaagNL(), werkdagen = LEVER_WERKDAGEN) {
  const [j, m, d] = vanaf.split('-').map(Number);
  let dag = utc(j, m - 1, d), n = 0;
  while (n < werkdagen) { dag = plusDagen(dag, 1); if (isWerkdag(dag)) n++; }
  return iso(dag);
}

export const datumNL = (isoDatum) => { const [j, m, d] = isoDatum.split('-'); return `${Number(d)}-${Number(m)}-${j}`; };
