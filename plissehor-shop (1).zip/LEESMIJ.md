# Plissehor.com – webshop

## Online zetten (eenmalig)
1. Pak deze map uit en open een terminal in de map `webshop`.
2. Voer het deploy-commando uit dat Claude je gaf (Node.js 20 of nieuwer nodig).
3. Stel in Netlify (Project configuration > Environment variables) de volgende variabelen in,
   met "Functions" aangevinkt bij de scope, en deploy daarna opnieuw:
   - MOLLIE_API_KEY  – begin met je test-sleutel (test_...), later je live-sleutel (live_...)
   - ADMIN_TOKEN     – een lang, willekeurig wachtwoord voor de beheerpagina
   - MAIL_TO         – (optioneel) e-mailadres voor bestelmeldingen
   - RESEND_API_KEY  – (optioneel) sleutel van resend.com voor de e-mails
   - MAIL_FROM       – (optioneel) afzender, bijvoorbeeld "Plissehor.com <bestellingen@jouwdomein.nl>"
4. Het beheergedeelte (dashboard, bestellingen, klanten, archief en export) vind je op /beheer/ (ook /admin).
   Je logt in met het wachtwoord uit ADMIN_TOKEN (minimaal 12 tekens, kies iets lang en uniek).

## Bestanden
- public/pricing.mjs        – alle prijzen en regels (browser en server gebruiken hetzelfde bestand)
- public/index.html, app.js – winkel, configurator en afrekenen
- netlify/functions/        – bestellen, Mollie-webhook, status en beheerpagina

## Voor je live gaat
- public/meten.html en public/monteren.html zijn conceptversies. Zoek op `<mark>` en vul de gele
  delen in (montageplek, welke maat doorgeven, bevestigingsmethode, contactgegevens).
- Vul in public/voorwaarden.html en privacy.html je bedrijfsgegevens in (tekst tussen [ ]).

## Huisstijl
- Kleuren: zwart (#000), goud (#C9A24D, hoog #E3C27C) en wit, in public/stijl.css bovenaan.
- Lettertype Oswald (lokaal in public/fonts, geen verbinding met Google nodig).
- public/logo.png en public/favicon.png zijn uit je schermafbeelding gehaald. Vervang ze door een
  hoge-resolutie of SVG-versie van je logo zodra je die hebt (zelfde bestandsnaam, of pas de <img> aan).

## Domein
- Gebruikt wordt https://www.plissehor.com. Koppel in Netlify (Domain management) zowel www.plissehor.com als
  plissehor.com; het apex-domein wordt dan automatisch doorgestuurd naar www (zie netlify.toml).

## E-mails (bevestiging voor klanten en melding voor jou)
1. Maak een gratis account bij resend.com en voeg het domein plissehor.com toe (je krijgt DNS-records om te plaatsen).
2. Zodra het domein is geverifieerd, stel je in Netlify in:
   - RESEND_API_KEY  – je API-sleutel
   - MAIL_TO         – info@plissehor.com (jouw melding bij elke betaalde bestelling)
   - MAIL_FROM       – Plissehor.com <bestellingen@plissehor.com>
3. Na elke betaling krijgt de klant automatisch een bevestiging (met reply-to info@plissehor.com).
   Zonder geverifieerd domein kan Resend alleen naar je eigen e-mailadres sturen.

## Beheergedeelte (alleen voor jou)
- Adres: https://www.plissehor.com/beheer/  (niet zichtbaar voor zoekmachines of in het menu).
- Inloggen met het wachtwoord uit ADMIN_TOKEN. Na 5 foute pogingen volgt 15 minuten blokkade. Je blijft 8 uur ingelogd.
- Alle bestellingen blijven permanent bewaard. "Archiveren" verbergt alleen uit de actieve lijst.
- Exporteer bestellingen, producten per regel en klanten als CSV (Excel) of maak een volledige JSON-back-up.
  Doe dat bijvoorbeeld elke maand, en bewaar het bestand veilig (het bevat persoonsgegevens).
